# gojobs-ca

Find **Go / Golang jobs in Canada** by querying company career boards directly —
not by scraping third-party job sites.

## The idea

You don't scrape thousands of company websites' raw HTML (fragile, breaks
constantly). Instead you hit the **ATS (Applicant Tracking System)** that each
company already uses. A handful of ATS platforms host most tech job boards, and
each exposes a public, structured JSON endpoint per company:

| ATS        | Endpoint used                                                        |
|------------|----------------------------------------------------------------------|
| Greenhouse | `https://boards-api.greenhouse.io/v1/boards/{slug}/jobs?content=true`|
| Lever      | `https://api.lever.co/v0/postings/{slug}?mode=json`                  |
| Ashby      | `https://api.ashbyhq.com/posting-api/job-board/{slug}`               |

So "scrape every company site" becomes "query the ATS for each company on my
list" — reliable, fast, and no HTML parsing. The tool fetches all companies
concurrently, keeps only postings that look like **Go roles** *and* are in
**Canada**, and stores them in `jobs.json`. A small web UI lets you browse them.

## Requirements

- Go 1.22+ (`go version`). No external dependencies — standard library only.

## Quick start

```bash
go build -o gojobs-ca .

./gojobs-ca scrape        # fetch + filter into jobs.json
./gojobs-ca serve         # open http://localhost:8080
```

Re-run `scrape` anytime; results are merged and de-duplicated by URL, so the
job list accumulates and stays current.

## Commands

```
gojobs-ca scrape [flags]
  -companies string   companies list           (default "companies.json")
  -out       string   output file              (default "jobs.json")
  -remote             also keep remote roles that don't name a Canadian city
  -concurrency int    parallel fetches         (default 8)
  -timeout   duration per-request timeout       (default 20s)

gojobs-ca serve [flags]
  -jobs string   jobs file    (default "jobs.json")
  -addr string   listen addr  (default ":8080")
```

Tip: add `-remote` to catch "Remote (North America)" style postings that don't
explicitly say Canada. Without it, only postings naming a Canadian location
(or an explicitly remote-in-Canada posting) are kept.

## Adding companies

`companies.json` is just a list. Add any company on Greenhouse, Lever, or Ashby:

```json
{ "name": "Acme", "ats": "greenhouse", "slug": "acme" }
```

**Finding the slug** (the important part): open the company's careers page and
look at the URL or the network tab.

- Greenhouse boards look like `boards.greenhouse.io/acme` or
  `job-boards.greenhouse.io/acme` → slug is `acme`.
- Lever boards look like `jobs.lever.co/acme` → slug is `acme`.
- Ashby boards look like `jobs.ashbyhq.com/acme` → slug is `acme`.

If a slug is wrong the tool logs a `404 — slug not found` and skips it, so a bad
entry never breaks a run. **The shipped `companies.json` is a starter list — the
slugs are best guesses and you should verify each one.** The value of the tool is
your own curated company list; the more Go-heavy Canadian companies you add, the
better it gets.

## How matching works (`filter.go`)

- **Go role:** `golang` anywhere in the title or description, *or* a standalone
  `Go` in the title next to a role word (Engineer / Developer / Backend / …).
  A bare "go" in prose ("ready to go", "go-to-market") is deliberately ignored.
- **Canada:** the location or description names Canada, a province, or a major
  Canadian city. Remote handling is controlled by the `-remote` flag.

Both rules are simple regexes — tune them to taste. Run `go test ./...` after
changes; `filter_test.go` covers the tricky cases.

## Ideas to extend

- Add more ATS providers (Workday, SmartRecruiters, Recruitee, Workable).
- Add a cron/systemd timer to `scrape` daily and diff for *new* postings.
- Email/Slack a digest of postings added since the last run.
- Add seniority or salary parsing to the filter.

## A note on etiquette

These are public endpoints, but be polite: the default concurrency (8) and a
once-a-day scrape are plenty. Don't hammer them.
