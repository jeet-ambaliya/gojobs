package main

import (
	"flag"
	"fmt"
	"html/template"
	"log"
	"net/http"
	"time"
)

func runServe(args []string) {
	fs := flag.NewFlagSet("serve", flag.ExitOnError)
	jobsPath := fs.String("jobs", "jobs.json", "path to the jobs file")
	addr := fs.String("addr", ":8080", "address to listen on")
	_ = fs.Parse(args)

	tmpl := template.Must(template.New("page").Funcs(template.FuncMap{
		"since": humanSince,
		"date":  func(t time.Time) string { return t.Format("2006-01-02") },
	}).Parse(pageTemplate))

	http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/" {
			http.NotFound(w, r)
			return
		}
		jobs := loadJobsQuiet(*jobsPath) // reload each request so re-scrapes show up live
		data := struct {
			Jobs      []Job
			Count     int
			Generated string
		}{jobs, len(jobs), time.Now().Format("2006-01-02 15:04")}
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		if err := tmpl.Execute(w, data); err != nil {
			log.Printf("render: %v", err)
		}
	})

	log.Printf("Serving %s at http://localhost%s  (Ctrl+C to stop)", *jobsPath, *addr)
	if err := http.ListenAndServe(*addr, nil); err != nil {
		log.Fatal(err)
	}
}

func humanSince(t time.Time) string {
	if t.IsZero() {
		return "—"
	}
	d := time.Since(t)
	switch {
	case d < 24*time.Hour:
		return "today"
	case d < 48*time.Hour:
		return "1d"
	case d < 30*24*time.Hour:
		return fmt.Sprintf("%dd", int(d.Hours()/24))
	default:
		return fmt.Sprintf("%dmo", int(d.Hours()/24/30))
	}
}

const pageTemplate = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>gojobs · Go roles in Canada</title>
<style>
  :root{
    --bg:#0b1016; --surface:#121924; --surface-2:#0f1620;
    --line:#1e2a38; --text:#e7eef5; --muted:#7d8ea0;
    --go:#00add8; --go-dim:#0b3a48; --maple:#e8564b;
    --mono:ui-monospace,"JetBrains Mono","SF Mono",Menlo,Consolas,monospace;
    --sans:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;
  }
  *{box-sizing:border-box}
  body{margin:0;background:var(--bg);color:var(--text);font-family:var(--sans);
    line-height:1.5;-webkit-font-smoothing:antialiased}
  .wrap{max-width:920px;margin:0 auto;padding:32px 20px 80px}
  header{border-bottom:1px solid var(--line);padding-bottom:20px;margin-bottom:24px}
  .cmd{font-family:var(--mono);font-size:13px;color:var(--muted)}
  .cmd .dollar{color:var(--go)}
  .cmd .flag{color:var(--text)}
  h1{font-family:var(--mono);font-weight:700;font-size:30px;letter-spacing:-.5px;
    margin:10px 0 4px}
  h1 .dot{color:var(--go)}
  .tagline{color:var(--muted);font-size:14px;margin:0}
  .controls{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin:22px 0 8px}
  #q{flex:1;min-width:220px;background:var(--surface);border:1px solid var(--line);
    color:var(--text);font-family:var(--mono);font-size:14px;padding:10px 12px;border-radius:8px}
  #q:focus{outline:none;border-color:var(--go)}
  .toggle{font-family:var(--mono);font-size:13px;color:var(--muted);
    display:flex;align-items:center;gap:7px;cursor:pointer;user-select:none;
    background:var(--surface);border:1px solid var(--line);padding:9px 12px;border-radius:8px}
  .toggle input{accent-color:var(--go)}
  .meta{font-family:var(--mono);font-size:12px;color:var(--muted);margin:4px 2px 20px}
  #shown{color:var(--go)}
  ul{list-style:none;margin:0;padding:0}
  li.job{border:1px solid var(--line);background:var(--surface);border-radius:10px;
    padding:16px 18px;margin-bottom:10px;transition:border-color .12s}
  li.job:hover{border-color:var(--go-dim)}
  .row1{display:flex;justify-content:space-between;gap:14px;align-items:baseline}
  .title{font-weight:600;font-size:16px;text-decoration:none;color:var(--text)}
  .title:hover{color:var(--go)}
  .co{font-family:var(--mono);font-size:12px;color:var(--go);white-space:nowrap}
  .tags{display:flex;gap:6px;flex-wrap:wrap;margin-top:9px;
    font-family:var(--mono);font-size:11px}
  .tag{padding:2px 8px;border-radius:20px;border:1px solid var(--line);color:var(--muted)}
  .tag.loc{border-color:var(--go-dim);color:#8fd6e8}
  .tag.remote{border-color:#5a2b28;color:var(--maple)}
  .tag.age{margin-left:auto;border:none;color:var(--muted)}
  .snip{color:var(--muted);font-size:13px;margin-top:10px}
  .empty{font-family:var(--mono);color:var(--muted);border:1px dashed var(--line);
    border-radius:10px;padding:40px 20px;text-align:center}
  footer{margin-top:30px;font-family:var(--mono);font-size:11px;color:var(--muted)}
  @media (prefers-reduced-motion:reduce){*{transition:none!important}}
</style>
</head>
<body>
<div class="wrap">
  <header>
    <div class="cmd"><span class="dollar">$</span> gojobs serve <span class="flag">--lang=go --country=CA</span></div>
    <h1>gojobs<span class="dot">.</span>ca</h1>
    <p class="tagline">Go roles in Canada, pulled straight from company ATS boards — no middleman job sites.</p>
    <div class="controls">
      <input id="q" type="search" placeholder="filter by title, company, city…" autofocus>
      <label class="toggle"><input type="checkbox" id="remoteOnly"> remote only</label>
    </div>
    <div class="meta"><span id="shown">{{.Count}}</span> / {{.Count}} roles · scanned {{.Generated}}</div>
  </header>

  {{if .Jobs}}
  <ul id="list">
    {{range .Jobs}}
    <li class="job" data-remote="{{.Remote}}"
        data-search="{{.Title}} {{.Company}} {{.Location}}">
      <div class="row1">
        <a class="title" href="{{.URL}}" target="_blank" rel="noopener">{{.Title}}</a>
        <span class="co">{{.Company}}</span>
      </div>
      <div class="tags">
        {{if .Location}}<span class="tag loc">{{.Location}}</span>{{end}}
        {{if .Remote}}<span class="tag remote">remote</span>{{end}}
        <span class="tag">{{.Source}}</span>
        <span class="tag age">{{since .PostedAt}}</span>
      </div>
      {{if .Snippet}}<div class="snip">{{.Snippet}}</div>{{end}}
    </li>
    {{end}}
  </ul>
  <div class="empty" id="noresults" style="display:none">no roles match that filter.</div>
  {{else}}
  <div class="empty">jobs.json is empty. Run <b>gojobs-ca scrape</b> first.</div>
  {{end}}

  <footer>data is only as good as companies.json — edit it to add companies and ATS slugs.</footer>
</div>

<script>
  const q = document.getElementById('q');
  const remoteOnly = document.getElementById('remoteOnly');
  const items = Array.from(document.querySelectorAll('li.job'));
  const shown = document.getElementById('shown');
  const noResults = document.getElementById('noresults');

  function apply(){
    const term = q.value.trim().toLowerCase();
    const remote = remoteOnly.checked;
    let n = 0;
    for(const li of items){
      const hay = li.dataset.search.toLowerCase();
      const ok = (!term || hay.includes(term)) && (!remote || li.dataset.remote === 'true');
      li.style.display = ok ? '' : 'none';
      if(ok) n++;
    }
    if(shown) shown.textContent = n;
    if(noResults) noResults.style.display = (n === 0 && items.length) ? '' : 'none';
  }
  q.addEventListener('input', apply);
  remoteOnly.addEventListener('change', apply);
</script>
</body>
</html>`
