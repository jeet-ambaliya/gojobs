package main

import (
	"flag"
	"log"
	"net/http"
	"sync"
	"time"
)

func runScrape(args []string) {
	fs := flag.NewFlagSet("scrape", flag.ExitOnError)
	companiesPath := fs.String("companies", "companies.json", "path to the companies list")
	outPath := fs.String("out", "jobs.json", "path to write matched jobs")
	includeRemote := fs.Bool("remote", false, "also keep remote roles that don't name a Canadian location")
	concurrency := fs.Int("concurrency", 8, "how many companies to fetch in parallel")
	timeout := fs.Duration("timeout", 20*time.Second, "per-request timeout")
	_ = fs.Parse(args)

	companies, err := loadCompanies(*companiesPath)
	if err != nil {
		log.Fatalf("load companies: %v", err)
	}
	log.Printf("Scraping %d companies (concurrency %d)…\n", len(companies), *concurrency)

	client := &http.Client{Timeout: *timeout}
	sem := make(chan struct{}, *concurrency)
	var wg sync.WaitGroup
	var mu sync.Mutex
	var matched []Job
	var okCount, failCount int

	for _, c := range companies {
		wg.Add(1)
		sem <- struct{}{}
		go func(c Company) {
			defer wg.Done()
			defer func() { <-sem }()

			jobs, err := fetchCompany(client, c)

			mu.Lock()
			defer mu.Unlock()
			if err != nil {
				failCount++
				log.Printf("  ✗ %-24s %v", c.Name, err)
				return
			}
			kept := 0
			for _, j := range jobs {
				if !matchesGo(j.Title, j.Description) {
					continue
				}
				canada, remote := matchesCanada(j.Location, j.Description, j.Remote)
				if !(canada || (*includeRemote && remote)) {
					continue
				}
				j.Remote = remote
				j.Description = "" // don't persist full text
				matched = append(matched, j)
				kept++
			}
			okCount++
			log.Printf("  ✓ %-24s %3d roles → %d Go/CA match", c.Name, len(jobs), kept)
		}(c)
	}
	wg.Wait()

	merged := mergeJobs(loadJobsQuiet(*outPath), matched)
	if err := saveJobs(*outPath, merged); err != nil {
		log.Fatalf("save: %v", err)
	}
	log.Printf("\nDone: %d ok, %d failed. %d total matching jobs in %s (run: gojobs-ca serve)",
		okCount, failCount, len(merged), *outPath)
}
